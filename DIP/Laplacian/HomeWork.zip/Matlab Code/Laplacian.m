function Laplacian()
img = imread('G:\Fig0458(a)(blurry_moon).tif');
%Spatial Domain
lapsp = fspecial('laplacian',0);

img2 = im2double(img);
imf2 = imfilter(img2, lapsp);

img3 = img2 - imf2;

figure;
subplot(1,2,1);imshow(img,[]);
subplot(1,2,2);imshow(img3,[]);


%Frequency Domain
lapsp = Huv(img);
laplac = lapsp.*(fft2(fftshift(img)));
imf = img2 - fftshift(real(ifft2(laplac)));

figure;
subplot(1,2,1);imshow(img,[]);
subplot(1,2,2);imshow(imf,[]);

end

function output=Huv(img)
[x,y]=size(img);
H = zeros(x,y);
for u=1:x
    for v=1:y
        H(u,v)=-(power(u-(x/2),2)+power(v-(y/2),2));
    end
end
output=H;
end